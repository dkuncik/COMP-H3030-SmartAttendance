<?php

	include 'db_config.php';

	$con = mysqli_connect($HOST, $USER, $PASSWORD, $DB_NAME);

	//$recievedName = "sdsd";
	//$recievedPassword = "sdas";
	//$recievedModuleCode = "sddsda";
	$recievedName = $_POST['NAME'];
	$recievedNFC = $_POST['NFC'];
	$recievedModuleCode = $_POST['MODULECODE'];
	$recievedDT = $_POST['Date&Time'];

	$sqlQuery = "INSERT INTO `students`(`name`, `roomnumber`,`moduleCode`, `datetime`) VALUES('$recievedName', '$recievedNFC', '$recievedModuleCode', '$recievedDT')";

	//Check that the query is successful or not

	if(mysqli_query($con, $sqlQuery)){

		//if successful

		$result["status"] = TRUE;
		$result["remarks"] = "Saved Successfully";



	}else{

		//if failure

		$result["status"] = FALSE;
		$result["remarks"] = "Some Error Occured";
	}

	mysqli_close($con); 	//Closin the db connection

//	print(json_encode($result));	//printing the result in JSON Format
	print(json_encode($result));


?>