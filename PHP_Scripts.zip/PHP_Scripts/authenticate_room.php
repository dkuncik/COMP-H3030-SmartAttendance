<?php

	include 'db_config.php';

    $con = mysqli_connect($HOST, $USER, $PASSWORD, $DB_NAME);

        $recievedNFC =  $_POST['NFC'];

    	$sqlQuery = "SELECT * FROM NFCclasses WHERE nfc = '$recievedNFC'";
        $found = mysqli_query($con, $sqlQuery);		
		$num_rows = mysqli_num_rows($found);

    	//Check that the query is successful or not
		
    	if($num_rows > 0){
                 //if successful

            $result["status"] = TRUE;
            $result["remarks"] = "Good classroom";


    	}else{

    		//if failure

    		$result["status"] = FALSE;
    		$result["remarks"] = "Not a classroom";
    	}

    	mysqli_close($con); 	//Closin the db connection

    //	print(json_encode($result));	//printing the result in JSON Format
    	print(json_encode($result));

?>