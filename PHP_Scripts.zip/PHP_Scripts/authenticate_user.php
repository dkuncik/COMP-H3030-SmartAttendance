<?php

	include 'db_config.php';

    $con = mysqli_connect($HOST, $USER, $PASSWORD, $DB_NAME);

        $recievedID =  $_POST['StudentID'];
        $recievedPassword =  $_POST['StudentPassword'];
        //$recievedID =  "B00127964";
        //$recievedPassword =  "s";

    	$sqlQuery = "SELECT * FROM `student_login` WHERE student_id = '$recievedID' AND password = '$recievedPassword'";
        $found = mysqli_query($con, $sqlQuery);		
		$num_rows = mysqli_num_rows($found);

    	//Check that the query is successful or not
		
    	if($num_rows > 0){
                 //if successful

            $result["status"] = TRUE;
            $result["remarks"] = "Correct Credentials";


    	}else{

    		//if failure

    		$result["status"] = FALSE;
    		$result["remarks"] = "Incorrect Credentials";
    	}

    	mysqli_close($con); 	//Closin the db connection

    //	print(json_encode($result));	//printing the result in JSON Format
    	print(json_encode($result));

?>