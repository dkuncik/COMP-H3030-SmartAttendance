<?php
	$HOST = "localhost";
	$USER = "dominic";
	$PASSWORD = "root";
	$DB_NAME = "SmartAttendance";

$conn = new mysqli($HOST, $USER, $PASSWORD);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>