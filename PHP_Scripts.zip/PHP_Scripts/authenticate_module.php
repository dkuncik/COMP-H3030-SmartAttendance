<?php
	include 'db_config.php';

    $con = mysqli_connect($HOST, $USER, $PASSWORD, $DB_NAME);

        $recievedModule =  $_POST['MODULE'];
        //$recievedModule =  "COMP H3030";

    	$sqlQuery = "SELECT * FROM ModuleAuth WHERE module_codes = '$recievedModule'";
        $found = mysqli_query($con, $sqlQuery);		
		$num_rows = mysqli_num_rows($found);

    	//Check that the query is successful or not
		
    	if($num_rows > 0){
                 //if successful

            $result["status"] = TRUE;
            $result["remarks"] = "Good Module";

    	}else{

    		//if failure

    		$result["status"] = FALSE;
    		$result["remarks"] = "Not a module";
    	}
    	mysqli_close($con); 	//Closin the db connection

    //	print(json_encode($result));	//printing the result in JSON Format
    	print(json_encode($result));

?>